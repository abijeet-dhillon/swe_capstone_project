# Comprehensive Demo Project for Milestone #2

This ZIP demonstrates **all major capabilities** of the Digital Work Artifact Miner system.

## Projects Included

### 1. **ecommerce-backend** (Python + Django + PostgreSQL)
- **Type**: Collaborative backend API
- **Highlights**: REST API, authentication, database models, tests
- **Skills**: Python, Django, PostgreSQL, JWT, Docker
- **Evidence**: High test coverage, badge in README, performance metrics

### 2. **mobile-shopping-app** (React Native + TypeScript)
- **Type**: Collaborative mobile frontend
- **Highlights**: Cross-platform mobile app, state management, API integration
- **Skills**: React Native, TypeScript, Redux, REST APIs
- **Evidence**: Screenshots, user feedback document

### 3. **ml-recommendation-engine** (Python + TensorFlow)
- **Type**: Individual ML component
- **Highlights**: Machine learning model, Jupyter notebooks, data analysis
- **Skills**: Python, TensorFlow, Pandas, NumPy, Scikit-learn
- **Evidence**: Model performance graphs, research paper

### 4. **design-system** (Figma + Sketch files + Documentation)
- **Type**: Individual design work
- **Highlights**: UI/UX design files, style guides, prototypes
- **Skills**: UI/UX Design, Figma, Adobe XD
- **Evidence**: Design critique feedback

### 5. **deployment-infrastructure** (Terraform + Docker + Kubernetes)
- **Type**: Collaborative DevOps
- **Highlights**: Infrastructure as code, CI/CD pipelines, monitoring
- **Skills**: Terraform, Docker, Kubernetes, GitHub Actions
- **Evidence**: Deployment logs, uptime metrics

## What This Demo Tests

### Analysis Capabilities
- ✅ Multiple programming languages (Python, TypeScript, JavaScript, HCL)
- ✅ Multiple frameworks (Django, React Native, TensorFlow, Redux)
- ✅ Git repository analysis (commits, contributors, chronology)
- ✅ Code quality metrics (LOC, file counts, complexity)
- ✅ Documentation analysis (README, docs folders, inline comments)
- ✅ Test coverage detection
- ✅ Image and media file categorization
- ✅ Collaboration vs. individual project detection

### Presentation Features
- ✅ Portfolio item generation (taglines, descriptions, key features)
- ✅ Resume bullet generation (quantifiable achievements)
- ✅ Success metrics calculation (badges, feedback, quality scores)
- ✅ Skill extraction and categorization
- ✅ Technology stack identification
- ✅ User role assignment ("Lead Backend Developer", "ML Engineer", etc.)

### Filtering & Search
- ✅ Filter by language (Python, TypeScript, etc.)
- ✅ Filter by framework (Django, React, TensorFlow)
- ✅ Combined filters
- ✅ Project listing and comparison

## Usage

1. **Analyze the demo:**
   ```bash
   python -m src.pipeline analyze tests/demo_capstone_project.zip
   ```

2. **List all projects:**
   ```bash
   python -m src.pipeline list
   ```

3. **Filter by technology:**
   ```bash
   python -m src.pipeline list --language Python
   python -m src.pipeline list --framework Django
   python -m src.pipeline list --language Python --framework Django
   ```

4. **View specific project portfolio:**
   ```bash
   python -m src.pipeline show-portfolio --project-id <ID>
   ```

5. **View resume item:**
   ```bash
   python -m src.pipeline show-resume --project-id <ID>
   ```

## Expected Insights

- **5 distinct projects** identified
- **10+ programming languages/frameworks** detected
- **200+ commits** across Git repositories
- **3 collaborative projects** (multiple contributors)
- **2 individual projects** (single author)
- **Evidence of success**: badges, feedback docs, metrics
- **Diverse skill set**: Backend, Frontend, ML, DevOps, Design
