"""
Hybrid Recommendation System
Combines collaborative filtering and content-based approaches.
"""
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Tuple, Dict
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class HybridRecommender:
    """
    Hybrid recommendation system combining collaborative and content-based filtering.
    
    Attributes:
        model: TensorFlow neural collaborative filtering model
        item_features: Matrix of item content features
        user_item_matrix: Sparse user-item interaction matrix
        alpha: Weight for collaborative filtering (1-alpha for content-based)
    """
    
    def __init__(self, embedding_dim: int = 64, alpha: float = 0.7):
        """
        Initialize hybrid recommender.
        
        Args:
            embedding_dim: Dimension of user/item embeddings
            alpha: Weight for collaborative filtering (0-1)
        """
        self.embedding_dim = embedding_dim
        self.alpha = alpha
        self.model = None
        self.item_features = None
        self.user_item_matrix = None
        self.item_similarity = None
        
    def build_ncf_model(self, num_users: int, num_items: int) -> tf.keras.Model:
        """
        Build Neural Collaborative Filtering model.
        
        Args:
            num_users: Number of unique users
            num_items: Number of unique items
            
        Returns:
            Compiled TensorFlow model
        """
        # User embedding path
        user_input = tf.keras.layers.Input(shape=(1,), name='user_input')
        user_embedding = tf.keras.layers.Embedding(
            num_users,
            self.embedding_dim,
            name='user_embedding'
        )(user_input)
        user_vec = tf.keras.layers.Flatten()(user_embedding)
        
        # Item embedding path
        item_input = tf.keras.layers.Input(shape=(1,), name='item_input')
        item_embedding = tf.keras.layers.Embedding(
            num_items,
            self.embedding_dim,
            name='item_embedding'
        )(item_input)
        item_vec = tf.keras.layers.Flatten()(item_embedding)
        
        # Concatenate embeddings
        concat = tf.keras.layers.Concatenate()([user_vec, item_vec])
        
        # MLP layers
        dense1 = tf.keras.layers.Dense(128, activation='relu')(concat)
        dropout1 = tf.keras.layers.Dropout(0.3)(dense1)
        dense2 = tf.keras.layers.Dense(64, activation='relu')(dropout1)
        dropout2 = tf.keras.layers.Dropout(0.3)(dense2)
        dense3 = tf.keras.layers.Dense(32, activation='relu')(dropout2)
        
        # Output layer
        output = tf.keras.layers.Dense(1, activation='sigmoid')(dense3)
        
        model = tf.keras.Model(inputs=[user_input, item_input], outputs=output)
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy', tf.keras.metrics.AUC(name='auc')]
        )
        
        return model
    
    def fit(self,
            user_item_matrix: np.ndarray,
            item_features: np.ndarray,
            epochs: int = 20,
            batch_size: int = 256,
            validation_split: float = 0.2) -> Dict[str, List[float]]:
        """
        Train the hybrid recommendation model.
        
        Args:
            user_item_matrix: User-item interaction matrix (users x items)
            item_features: Item content features matrix (items x features)
            epochs: Number of training epochs
            batch_size: Training batch size
            validation_split: Fraction of data for validation
            
        Returns:
            Dictionary of training history metrics
        """
        logger.info(f"Training hybrid recommender with {user_item_matrix.shape[0]} users "
                   f"and {user_item_matrix.shape[1]} items")
        
        self.user_item_matrix = user_item_matrix
        self.item_features = item_features
        
        # Build collaborative filtering model
        num_users, num_items = user_item_matrix.shape
        self.model = self.build_ncf_model(num_users, num_items)
        
        # Prepare training data
        X_users, X_items, y = self._prepare_training_data(user_item_matrix)
        
        # Train model
        history = self.model.fit(
            [X_users, X_items],
            y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=validation_split,
            callbacks=[
                tf.keras.callbacks.EarlyStopping(
                    monitor='val_loss',
                    patience=3,
                    restore_best_weights=True
                ),
                tf.keras.callbacks.ReduceLROnPlateau(
                    monitor='val_loss',
                    factor=0.5,
                    patience=2
                )
            ],
            verbose=1
        )
        
        # Compute item similarity matrix for content-based filtering
        self.item_similarity = cosine_similarity(item_features)
        
        logger.info(f"Training completed. Final validation loss: {history.history['val_loss'][-1]:.4f}")
        
        return history.history
    
    def _prepare_training_data(self, user_item_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Convert user-item matrix to training samples.
        
        Args:
            user_item_matrix: Sparse user-item interaction matrix
            
        Returns:
            Tuple of (user_ids, item_ids, labels)
        """
        num_users, num_items = user_item_matrix.shape
        
        # Positive samples
        pos_users, pos_items = np.where(user_item_matrix > 0)
        pos_labels = np.ones(len(pos_users))
        
        # Negative sampling
        num_negatives = len(pos_users)
        neg_users = np.random.randint(0, num_users, num_negatives)
        neg_items = np.random.randint(0, num_items, num_negatives)
        neg_labels = np.zeros(num_negatives)
        
        # Combine positive and negative samples
        X_users = np.concatenate([pos_users, neg_users])
        X_items = np.concatenate([pos_items, neg_items])
        y = np.concatenate([pos_labels, neg_labels])
        
        # Shuffle
        indices = np.arange(len(y))
        np.random.shuffle(indices)
        
        return X_users[indices], X_items[indices], y[indices]
    
    def predict(self, user_id: int, item_ids: List[int]) -> np.ndarray:
        """
        Predict interaction scores for user-item pairs.
        
        Args:
            user_id: User identifier
            item_ids: List of item identifiers
            
        Returns:
            Array of prediction scores
        """
        if self.model is None:
            raise ValueError("Model not trained. Call fit() first.")
        
        user_ids = np.array([user_id] * len(item_ids))
        item_ids = np.array(item_ids)
        
        # Collaborative filtering predictions
        cf_scores = self.model.predict([user_ids, item_ids], verbose=0).flatten()
        
        # Content-based predictions (average similarity to user's liked items)
        user_liked = np.where(self.user_item_matrix[user_id] > 0)[0]
        if len(user_liked) > 0:
            cb_scores = np.mean([self.item_similarity[item_id, user_liked] 
                                for item_id in item_ids], axis=1)
        else:
            cb_scores = np.zeros(len(item_ids))
        
        # Hybrid combination
        hybrid_scores = self.alpha * cf_scores + (1 - self.alpha) * cb_scores
        
        return hybrid_scores
    
    def recommend(self, user_id: int, n: int = 10, exclude_seen: bool = True) -> List[Tuple[int, float]]:
        """
        Generate top-N recommendations for a user.
        
        Args:
            user_id: User identifier
            n: Number of recommendations to generate
            exclude_seen: Whether to exclude items user has already interacted with
            
        Returns:
            List of (item_id, score) tuples sorted by score
        """
        num_items = self.user_item_matrix.shape[1]
        all_items = np.arange(num_items)
        
        if exclude_seen:
            seen_items = np.where(self.user_item_matrix[user_id] > 0)[0]
            candidate_items = np.setdiff1d(all_items, seen_items)
        else:
            candidate_items = all_items
        
        scores = self.predict(user_id, candidate_items.tolist())
        
        # Get top-N items
        top_indices = np.argsort(scores)[::-1][:n]
        recommendations = [(candidate_items[i], scores[i]) for i in top_indices]
        
        return recommendations
    
    def evaluate(self, test_user_item_matrix: np.ndarray, k: int = 10) -> Dict[str, float]:
        """
        Evaluate model on test data.
        
        Args:
            test_user_item_matrix: Test user-item interactions
            k: Number of recommendations to evaluate
            
        Returns:
            Dictionary of evaluation metrics
        """
        num_users = test_user_item_matrix.shape[0]
        precisions = []
        recalls = []
        
        for user_id in range(num_users):
            # Get ground truth items
            true_items = set(np.where(test_user_item_matrix[user_id] > 0)[0])
            
            if len(true_items) == 0:
                continue
            
            # Get recommendations
            recs = self.recommend(user_id, n=k, exclude_seen=True)
            rec_items = set([item_id for item_id, _ in recs])
            
            # Calculate metrics
            hits = len(rec_items & true_items)
            precision = hits / k if k > 0 else 0
            recall = hits / len(true_items) if len(true_items) > 0 else 0
            
            precisions.append(precision)
            recalls.append(recall)
        
        return {
            f'precision@{k}': np.mean(precisions),
            f'recall@{k}': np.mean(recalls),
            'coverage': len(np.unique([i for rec in [self.recommend(u, n=k) for u in range(num_users)] 
                                      for i, _ in rec])) / self.user_item_matrix.shape[1]
        }
