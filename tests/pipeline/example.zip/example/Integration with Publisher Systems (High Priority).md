| **Task**                             | **Owner**                    | **Description**                                                                 | **Status**       |
|--------------------------------------|------------------------------|---------------------------------------------------------------------------------|------------------|
| Server Creation API                  | Not Assigned                 | Develop the API for creating and managing servers.                              | Ready            |
| Text Channel API                     | Not Assigned                 | Build the API to handle operations in text channels (e.g., messages).           | Ready            |
| Dockerization                        | Not Assigned                 | Dockerize the web application for containerized deployment.                     | In Progress      |
| Channel Creation API                 | Tanishq Mehta & Raad Sarker  | Create the API for adding new communication channels.                           | In Progress      |
| Server Creation API                  | Not Assigned                 | Final review for server API implementation.                                     | In Review        |
| Set up Environment Config and Structure | Tahsin Jawwad              | Initialize the project with required config files (e.g., `.local.env`) and the necessary structure and layout using the tech stack (Next.js). | Completed        |
| Account Database Initialization (Clerk) | Tanishq Mehta              | Create an account with Clerk to access the authentication and user database.    | Completed        |
| Authentication Initialization (Middleware) | Tanishq Mehta           | Create the `middleware.ts` file to introduce Clerk authentication to the project. | Completed        |
| User Sign-up and Login API           | Tahsin Jawwad & Tanishq Mehta | Create API calls to register a user with Clerk and retrieve this information to link to the Stream server. | Completed        |
| Stream Setup                         | Abhinav Malik                | Create a Stream dashboard account and project to enable hosting of servers, channels, and chats. | Completed        |
| Stream Chat API                      | Raad Sarker                  | Create a tokens route to register users into the Stream server and implement a `MyChat` component to display channels and servers for the user. | Completed        |
| Homepage and Server List UI          | Not Assigned                 | Build the homepage and UI to display available servers.                         | Completed        |
| Discord Context                      | Kaiden Merchant              | Implement application context to support personalization and UI updates for servers and channels. | Completed        |
