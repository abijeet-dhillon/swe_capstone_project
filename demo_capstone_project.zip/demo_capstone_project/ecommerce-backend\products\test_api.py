"""
Unit tests for Product API endpoints
Tests cover CRUD operations, filtering, search, and edge cases.
"""
import pytest
from decimal import Decimal
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient
from products.models import Product, Category
from django.contrib.auth.models import User


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def test_user(db):
    return User.objects.create_user(
        username='testuser',
        email='test@example.com',
        password='testpass123'
    )


@pytest.fixture
def test_category(db):
    return Category.objects.create(
        name='Electronics',
        slug='electronics',
        description='Electronic products'
    )


@pytest.fixture
def test_product(db, test_category, test_user):
    return Product.objects.create(
        name='Wireless Headphones',
        slug='wireless-headphones',
        description='High-quality wireless headphones with noise cancellation',
        category=test_category,
        sku='WH-001',
        price=Decimal('149.99'),
        stock_quantity=50,
        created_by=test_user
    )


@pytest.mark.django_db
class TestProductListAPI:
    """Tests for product listing endpoint."""
    
    def test_list_products_success(self, api_client, test_product):
        """Test successful product listing."""
        url = reverse('product-list')
        response = api_client.get(url)
        
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data['results']) == 1
        assert response.data['results'][0]['name'] == 'Wireless Headphones'
    
    def test_list_products_filter_by_category(self, api_client, test_product, test_category):
        """Test filtering products by category."""
        url = reverse('product-list')
        response = api_client.get(url, {'category': test_category.id})
        
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data['results']) == 1
    
    def test_list_products_search_by_name(self, api_client, test_product):
        """Test searching products by name."""
        url = reverse('product-list')
        response = api_client.get(url, {'search': 'headphones'})
        
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data['results']) == 1
    
    def test_list_products_price_filter(self, api_client, test_product):
        """Test filtering products by price range."""
        url = reverse('product-list')
        response = api_client.get(url, {'min_price': 100, 'max_price': 200})
        
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data['results']) == 1


@pytest.mark.django_db
class TestProductDetailAPI:
    """Tests for product detail endpoint."""
    
    def test_get_product_detail_success(self, api_client, test_product):
        """Test retrieving product details."""
        url = reverse('product-detail', kwargs={'slug': test_product.slug})
        response = api_client.get(url)
        
        assert response.status_code == status.HTTP_200_OK
        assert response.data['name'] == 'Wireless Headphones'
        assert str(response.data['price']) == '149.99'
    
    def test_get_product_increments_view_count(self, api_client, test_product):
        """Test that viewing product increments view counter."""
        initial_count = test_product.view_count
        url = reverse('product-detail', kwargs={'slug': test_product.slug})
        api_client.get(url)
        
        test_product.refresh_from_db()
        assert test_product.view_count == initial_count + 1
    
    def test_get_nonexistent_product_returns_404(self, api_client):
        """Test 404 for non-existent product."""
        url = reverse('product-detail', kwargs={'slug': 'nonexistent'})
        response = api_client.get(url)
        
        assert response.status_code == status.HTTP_404_NOT_FOUND


@pytest.mark.django_db
class TestProductCreateAPI:
    """Tests for product creation endpoint."""
    
    def test_create_product_success(self, api_client, test_category, test_user):
        """Test successful product creation."""
        api_client.force_authenticate(user=test_user)
        url = reverse('product-list')
        data = {
            'name': 'New Product',
            'slug': 'new-product',
            'description': 'A new test product',
            'category': test_category.id,
            'sku': 'NP-001',
            'price': '99.99',
            'stock_quantity': 100
        }
        response = api_client.post(url, data, format='json')
        
        assert response.status_code == status.HTTP_201_CREATED
        assert Product.objects.filter(slug='new-product').exists()
    
    def test_create_product_unauthenticated_fails(self, api_client, test_category):
        """Test that unauthenticated users cannot create products."""
        url = reverse('product-list')
        data = {
            'name': 'New Product',
            'slug': 'new-product',
            'category': test_category.id,
            'price': '99.99'
        }
        response = api_client.post(url, data, format='json')
        
        assert response.status_code == status.HTTP_401_UNAUTHORIZED
    
    def test_create_product_duplicate_sku_fails(self, api_client, test_product, test_user):
        """Test that duplicate SKU is rejected."""
        api_client.force_authenticate(user=test_user)
        url = reverse('product-list')
        data = {
            'name': 'Another Product',
            'slug': 'another-product',
            'category': test_product.category.id,
            'sku': test_product.sku,  # Duplicate SKU
            'price': '99.99'
        }
        response = api_client.post(url, data, format='json')
        
        assert response.status_code == status.HTTP_400_BAD_REQUEST


@pytest.mark.django_db
class TestProductStockManagement:
    """Tests for inventory/stock management."""
    
    def test_record_purchase_decrements_stock(self, test_product):
        """Test that recording a purchase decrements stock."""
        initial_stock = test_product.stock_quantity
        test_product.record_purchase(quantity=5)
        
        assert test_product.stock_quantity == initial_stock - 5
        assert test_product.purchase_count == 5
    
    def test_is_low_stock_property(self, test_product):
        """Test low stock detection."""
        test_product.stock_quantity = 5
        test_product.low_stock_threshold = 10
        test_product.save()
        
        assert test_product.is_low_stock is True
    
    def test_is_in_stock_when_quantity_zero(self, test_product):
        """Test stock status when quantity is zero."""
        test_product.stock_quantity = 0
        test_product.continue_selling_when_out_of_stock = False
        test_product.save()
        
        assert test_product.is_in_stock is False
