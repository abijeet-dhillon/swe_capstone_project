@interface A: NSObject @end
