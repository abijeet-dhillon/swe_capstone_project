# Mobile Shopping App

![React Native](https://img.shields.io/badge/React%20Native-0.72-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)

Cross-platform mobile application for e-commerce built with React Native and TypeScript.

## Features

- **Product Browsing**: Browse products with infinite scroll and filters
- **Search**: Advanced search with autocomplete
- **Shopping Cart**: Add/remove items, update quantities
- **User Authentication**: Login, signup, OAuth support
- **Order Tracking**: Real-time order status updates
- **Push Notifications**: Order updates and promotions
- **Offline Support**: Browse previously viewed products offline

## Tech Stack

- React Native 0.72
- TypeScript 5.0
- Redux Toolkit (State Management)
- React Navigation 6
- Axios (API Client)
- React Native Firebase
- Jest + React Native Testing Library

## Team

- **Mobile Lead**: Cross-platform architecture, core features
- **UI/UX Developer**: Design implementation, animations
- **Backend Integration**: API integration, data synchronization

## Performance

- **App Size**: 12MB (Android), 15MB (iOS)
- **Startup Time**: <2 seconds
- **Frame Rate**: Consistent 60fps on mid-range devices

## Success Metrics

- **4.7/5 stars** on App Store (52 reviews)
- **4.5/5 stars** on Google Play (89 reviews)
- **10,000+ downloads** in first month
- **User Feedback**: "Smooth and intuitive interface"

## Installation

```bash
npm install
npx react-native run-android  # or run-ios
```

## Testing

```bash
npm test
npm run test:e2e
```
